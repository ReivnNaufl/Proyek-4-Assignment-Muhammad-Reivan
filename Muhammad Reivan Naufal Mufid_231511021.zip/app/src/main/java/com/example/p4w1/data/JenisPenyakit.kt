package com.example.p4w1.data

enum class JenisPenyakit(val displayName: String) {
    AIDS("AIDS"),
    CAMPAK("Campak"),
    DBD("DBD"),
    DIARE("Diare"),
    KUSTA("Kusta"),
    MALARIA("Malaria"),
    PNEUMONIA("Pneumonia"),
    TUBERCOLOSIS("TB Tubercolosis"),
    TETANUS("Tetanus"),;
}