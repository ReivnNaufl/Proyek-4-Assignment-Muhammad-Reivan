package com.example.p4w1.data

enum class Satuan(val displayName: String) {
    KASUS("Kasus")
}